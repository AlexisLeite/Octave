# Octave Notebook

Requiere Node.js 20+ y una instalación local de GNU Octave.

```sh
npx octave-notebook --port 4310 --projects ./projects
```
