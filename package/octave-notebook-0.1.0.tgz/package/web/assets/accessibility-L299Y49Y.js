import{bQ as e,X as s}from"./editorContextKeys-CAoU1TQ_.js";const i=s("accessibilityService"),a=new e("accessibilityModeEnabled",!1);export{a as C,i as I};
