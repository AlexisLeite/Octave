import{X as r}from"./editorContextKeys-CAoU1TQ_.js";const o=r("clipboardService");export{o as I};
