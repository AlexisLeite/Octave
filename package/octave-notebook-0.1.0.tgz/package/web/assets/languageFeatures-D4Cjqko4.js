import{X as e}from"./editorContextKeys-CAoU1TQ_.js";const r=e("ILanguageFeaturesService");export{r as I};
